import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';
import { AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'zyq30';
  //@Input() username: AbstractControl;
  isLogin: boolean = true;
  username: string = '';
  constructor(
    private router: Router,
    private auth: AuthService,

  ) {
    // this.username = this.['username'];
  }

  tiuchu() {
    this.auth.logout();
    this.router.navigate(['./login']);
  }
  ngOnInIt() {
  }
}
